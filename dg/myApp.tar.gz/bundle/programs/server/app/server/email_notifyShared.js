(function(){
//smtp://USERNAME:PASSWORD@HOST:PORT///
//process.env.MAIL_URL = 'smtp://postmaster%40meteorize.mailgun.org:YOURPASSWORD@smtp.mailgun.org:587';
/*

smtp_serverName = "email-smtp.us-east-1.amazonaws.com"
smtp_userName = "AKIAIUWOGP7U6NTYR52Q"
smtp_pw = "Anvg7kWYkVYf85R5SSjs7AXPGyie5NJlQvdIR6dgdAzy"
smtp_port = "25"

smtp_str = 'smtp://' + smtp_userName + ":" + smtp_pw + "@" + smtp_serverName + ":" + smtp_port; 
console.log(smtp_str)

process.env.MAIL_URL = smtp_str


//emailDomain = "sandboxcd8a4e5e448c4dafa642ead40c71363f.mailgun.org"
//emailPassword = "f4f3b0be6cdbbd437c32757883e474c7"




//process.env.MAIL_URL = "" 

Email.send({
      to: 'sirmartymoose@gmail.com',
      from: 'sirmartymoose@gmail.com',
      subject: 'hi there', 
      text: 'i am the text'
      })
      
      console.log("I AM THE CALLED EMAIL SCRIPT")
      

      
  */    
      

})();
