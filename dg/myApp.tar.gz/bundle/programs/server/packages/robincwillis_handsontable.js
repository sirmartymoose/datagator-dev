(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;



/* Exports */
if (typeof Package === 'undefined') Package = {};
Package['robincwillis:handsontable'] = {};

})();

//# sourceMappingURL=robincwillis_handsontable.js.map
